package com.project.orvbaapp11.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.auth.FirebaseUser;
import com.project.orvbaapp11.R;
import com.project.orvbaapp11.models.UserProfile;

public class MainActivity extends Activity {
    private TextView nameTextView;
    private TextView emailTextView;
    private TextView phoneNumberTextView;
    private TextView passwordTextView;
    private TextView roleTextView;
    private TextView approvedTextView;

    private FirebaseAuth firebaseAuth;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the Firebase authentication
        firebaseAuth = FirebaseAuth.getInstance();

        // Get the current user
        currentUser = firebaseAuth.getCurrentUser();


        // Create a new user profile with the given information
        UserProfile user = new UserProfile(currentUser.getName(), currentUser.getEmail(), currentUser.getPhoneNumber(), currentUser.getPassword(), currentUser.getRole(), currentUser.isApproved());

        // Initialize the views
        nameTextView = (TextView) findViewById(R.id.name_text_view);
        emailTextView = (TextView) findViewById(R.id.email_text_view);
        phoneNumberTextView = (TextView) findViewById(R.id.phone_number_text_view);
        passwordTextView = (TextView) findViewById(R.id.password_text_view);
        roleTextView = (TextView) findViewById(R.id.role_text_view);
        approvedTextView = (TextView) findViewById(R.id.approved_text_view);

        // Display the user's information
        nameTextView.setText(user.getName());
        emailTextView.setText(user.getEmail());
        phoneNumberTextView.setText(user.getPhoneNumber());
        passwordTextView.setText(user.getPassword());
        roleTextView.setText(user.getRole());
        approvedTextView.setText(user.isApproved() ? "Yes" : "No");
    }
}
